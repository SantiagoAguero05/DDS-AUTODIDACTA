function PiePagina() {
  return (
    <footer className="bg-light text-center py-4 mt-5">
      <div className="container">
        <small>&copy; 2024 BiciRent. Todos los derechos reservados.</small>
      </div>
    </footer>
  );
}

export default PiePagina;